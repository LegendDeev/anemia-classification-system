# Professor & Examiner Viva Voce Defense Guide
## Project: Anemia Classification Using Blood Parameters (CBC)

This guide provides structured, scientifically precise answers to the most common and challenging questions professors, external examiners, and evaluators ask during project defense, lab vivas, and presentations.

---

## Quick Reference Summary Table for Instant Answers

| Question | 10-Second Executive Summary |
| :--- | :--- |
| **What is the problem?** | Automated morphological classification of patient blood profiles into Non-Anemic, Anemic, and Compensated Microcytosis using 5 CBC measurements. |
| **Which dataset is used?** | The **TriHemo-MCV** dataset (5,037 clinical patient records from Bangladesh tertiary hospitals with institutional IRB ethical clearance and Data Validation Certificate). |
| **What are the 5 features?** | Hemoglobin (HGB), RBC count, Mean Corpuscular Volume (MCV), Mean Corpuscular Hemoglobin (MCH), and MCHC concentration. |
| **What are "All Five" algorithms?** | Logistic Regression, Decision Tree Classifier, Random Forest Classifier, Support Vector Machine (SVM), and K-Nearest Neighbors (KNN). |
| **Which algorithm performed best?** | **Random Forest Classifier** with **77.91% test accuracy** and **92.32% Multiclass ROC-AUC**. |
| **How do you handle invalid inputs?** | A 3-tier defensive validator (`src/validator.py`) intercepts non-numeric strings, negative numbers, out-of-range bounds, and biological ratio conflicts before data reaches the model. |

---

## Category 1: Clinical Domain & Hematology Questions

### Q1: Why do we need 5 blood parameters? Can't we just use Hemoglobin to detect anemia?
> **Examiner's Angle:** Testing whether you understand the medical domain or just treated it as a generic spreadsheet problem.

**Your Answer:**
* *"While Hemoglobin (Hb) is the primary threshold marker for diagnosing the general presence of anemia (WHO defines anemia as Hb < 12 g/dL for women and < 13 g/dL for men), **Hemoglobin alone cannot tell us the underlying cause or morphological type of anemia**."*
* *"To determine whether the anemia is **Microcytic** (small cells, e.g. Iron Deficiency or Thalassemia), **Normocytic** (normal sized cells, e.g. chronic kidney disease or acute blood loss), or **Macrocytic** (enlarged cells, e.g. Vitamin B12 / Folate deficiency), clinicians require **MCV** (cell volume) and **MCH/MCHC** (hemoglobin concentration per cell)."*
* *"Furthermore, **RBC count** is vital to distinguish Iron Deficiency Anemia from **Thalassemia Minor (Compensated Microcytosis)**, where hemoglobin remains compensated while RBC count increases to make up for smaller cell size."*

---

### Q2: What is the mathematical relationship between HGB, RBC, MCV, MCH, and MCHC?
> **Examiner's Angle:** Checking if you know the Wintrobe formulas that govern hematology.

**Your Answer:**
* *"In clinical hematology, these indices are mathematically linked through **Wintrobe's Equations**:"*
  1. $\text{MCV (fL)} = \frac{\text{Hematocrit (\%) } \times 10}{\text{RBC Count (M/µL)}}$ *(Measures average cell size)*
  2. $\text{MCH (pg)} = \frac{\text{Hemoglobin (g/dL) } \times 10}{\text{RBC Count (M/µL)}}$ *(Measures average hemoglobin mass per cell)*
  3. $\text{MCHC (g/dL)} = \frac{\text{MCH (pg)}}{\text{MCV (fL)}} \times 100$ *(Measures hemoglobin concentration inside the cell volume)*
* *"Our defensive validation layer (`src/validator.py`) specifically uses the formula $\text{MCHC} \approx \frac{\text{MCH}}{\text{MCV}} \times 100$ to check for biological consistency in user inputs."*

---

### Q3: What is "Compensated Microcytosis"? Why is it a distinct 3rd category in your project?
> **Examiner's Angle:** Testing your understanding of the target classes.

**Your Answer:**
* *"Compensated Microcytosis is a condition where red blood cells are abnormally small (low MCV < 80 fL), but the individual **is not clinically anemic** because their bone marrow compensates by producing an unusually high number of red blood cells (elevated RBC > 5.5 M/µL). As a result, total oxygen-carrying Hemoglobin remains within normal ranges."*
* *"This clinical phenotype is classical in asymptomatic carriers of **Thalassemia Minor (Thalassemia trait)**."*
* *"If a diagnostic model only looked at Hemoglobin, it would misclassify these patients as completely normal. Including Compensated Microcytosis allows early genetic counseling and prevents doctors from erroneously prescribing iron supplements, which can cause dangerous iron overload in thalassemia carriers."*

---

## Category 2: Data Preprocessing, Leakage & Robustness Questions

### Q4: What is "Data Leakage"? How did your pipeline strictly prevent it?
> **Examiner's Angle:** A critical viva question. Many students make the mistake of scaling the whole dataset before train-test splitting.

**Your Answer:**
* *"Data Leakage occurs when information from outside the training partition (i.e., from the validation or test sets) inadvertently leaks into the model during preprocessing, artificially inflating performance scores."*
* *"A common beginner mistake is calling `StandardScaler.fit_transform(X)` on the entire dataset prior to splitting. This allows the mean ($\mu$) and standard deviation ($\sigma$) of the test set to leak into the training features."*
* *"In our project, we implemented a leak-free pipeline in `src/preprocess.py`:"*
  1. We first performed **Stratified Splitting** into 70% Train, 15% Validation, and 15% Test.
  2. We called `scaler.fit(X_train)` **strictly on the training data only**.
  3. We then transformed `X_val` and `X_test` using the parameters $(\mu, \sigma)$ learned solely from `X_train`.
  4. The fitted scaler was saved as `models/scaler.joblib` and is reused during real-time inference.

---

### Q5: What if the user enters invalid inputs (negative numbers, strings, or absurd values)?
> **Examiner's Angle:** The classic professor "trap" question to see if your system crashes or outputs garbage.

**Your Answer:**
* *"In raw machine learning models, passing a string causes a fatal crash (`ValueError: could not convert string to float`), while passing negative numbers like `Hb = -5.0` silently computes matrix multiplications and yields dangerous, misleading medical predictions ('Garbage In, Garbage Out')."*
* *"To solve this, we implemented a **Three-Tier Defensive Validation Guard (`src/validator.py`)** that intercepts all data before it reaches the ML model:"*
  1. **Tier 1 (Type & Null Guard):** Intercepts non-numeric characters, `None`, and blank fields, displaying a clean error message without any Python traceback crash.
  2. **Tier 2 (Physiological Reference Bounds):** Rejects any negative number, zero, or humanly impossible laboratory values (e.g. Hemoglobin must be between 2.0 and 25.0 g/dL; RBC between 1.0 and 9.0 M/µL).
  3. **Tier 3 (Wintrobe Biological Consistency Check):** Checks if the reported MCHC conflicts with $\frac{MCH}{MCV} \times 100$. If there is a $>10$ g/dL discrepancy, it issues a clinical advisory warning.
* *"Both our CLI (`src/predict.py`) and Flask Web App (`app.py`) feature client-side and server-side validation to guarantee rock-solid stability."*

---

### Q6: Why did you use `StandardScaler` instead of `MinMaxScaler`?
> **Examiner's Angle:** Testing your rationale for feature scaling.

**Your Answer:**
* *"We chose `StandardScaler` (z-score standardization: $z = \frac{x - \mu}{\sigma}$) over `MinMaxScaler` for two reasons:"*
  1. **Outlier Sensitivity:** `MinMaxScaler` compresses all values strictly into $[0, 1]$ based on the minimum and maximum values. If a patient sample has an unusually high RBC or MCV value, `MinMaxScaler` compresses the rest of the normal distribution into a tiny sub-range. `StandardScaler` preserves the relative variance and centered distribution.
  2. **Model Compatibility:** Distance-based algorithms (KNN and SVM with RBF kernel) and regularized Logistic Regression assume that continuous features are zero-centered with comparable standard deviations.

---

### Q7: Why is Stratified K-Fold Cross-Validation preferred over regular K-Fold?
**Your Answer:**
* *"In standard K-Fold cross-validation, the dataset is divided randomly into $K$ subsets. In small partitions or multi-class scenarios, random splitting can accidentally create folds where one class is underrepresented or missing entirely."*
* *"**Stratified K-Fold** guarantees that every individual fold preserves the exact class percentage proportions (33% Non-Anemic, 34% Anemic, 33% Microcytosis) as the global dataset. This ensures that every fold is representative and provides an unbiased estimate of generalization error."*

---

## Category 3: Machine Learning Algorithms & Architectures

### Q8: Briefly explain how each of the "All Five" algorithms works.
> **Examiner's Angle:** Checking your core computer science / machine learning fundamentals.

**Your Answer:**
1. **Logistic Regression (Multinomial Softmax):** Computes linear combinations of the standardized blood parameters ($z_k = \mathbf{w}_k^T \mathbf{x} + b_k$) and passes them through a **Softmax function** to generate calibrated class probabilities. It is optimized using Cross-Entropy Loss with L2 regularization ($C=1.0$).
2. **Decision Tree Classifier (CART):** A non-parametric rule-based model that recursively partitions the 5D feature space using binary thresholds that maximize **Gini Impurity reduction**. It handles non-linear step cutoffs naturally.
3. **Random Forest Classifier (Ensemble Bagging):** Trains an ensemble of 100 de-correlated decision trees on bootstrap resamples (Bagging) while restricting each node split to a random subset of features ($\sqrt{5} \approx 2$ features). Final prediction is determined by majority voting.
4. **Support Vector Machine (SVM):** Finds the optimal separating hyperplane that maximizes the geometric margin between classes. Because the blood measurements are non-linearly separable, it utilizes the **Radial Basis Function (RBF) Kernel** ($K(\mathbf{x}, \mathbf{x}') = \exp(-\gamma ||\mathbf{x} - \mathbf{x}'||^2)$) to project points into an implicit higher-dimensional space.
5. **K-Nearest Neighbors (KNN):** An instance-based lazy learner that measures the Euclidean distance ($L_2$ norm) between a query patient vector and all stored training samples, assigning the class based on inverse-distance-weighted majority vote among the $k = 5$ closest neighbors.

---

### Q9: Why did Random Forest perform the best among all five algorithms?
**Your Answer:**
* *"Random Forest achieved the highest test accuracy (**77.91%**) and top **ROC-AUC (92.32%)** for two fundamental reasons:"*
  1. **Non-Linear Interactions:** Medical diagnoses depend on interactive thresholds (e.g. low MCV + low RBC = iron deficiency, but low MCV + high RBC = thalassemia). Decision trees capture these orthogonal step interactions much better than linear hyperplanes.
  2. **Variance Reduction via Bagging:** While a single Decision Tree tends to overfit training noise (reflected by its higher CV standard deviation of $\pm 1.35\%$), Random Forest averages 100 trees, which substantially reduces prediction variance without increasing bias (reflected by its lower CV standard deviation of $\pm 0.84\%$).

---

### Q10: What does the hyperparameter $C$ represent in Logistic Regression and SVM?
**Your Answer:**
* *"In both Logistic Regression and SVM, **$C$ is the inverse regularization parameter** ($C = \frac{1}{\lambda}$):"*
  * A **large $C$** imposes weak regularization: the model prioritizes fitting every training point perfectly, which risks **overfitting**.
  * A **small $C$** imposes strong regularization: the model tolerates training errors in favor of a simpler, smoother decision boundary, which risks **underfitting**.
* *"We set $C = 1.0$ as a balanced trade-off between margin size and classification error penalty."*

---

### Q11: What is the "Curse of Dimensionality" and how does it affect KNN?
**Your Answer:**
* *"In K-Nearest Neighbors, as the number of feature dimensions grows, the volume of the feature space increases exponentially, making data points sparse. In high-dimensional spaces, the distance between the nearest neighbor and the furthest neighbor approaches zero, degrading Euclidean distance calculations."*
* *"In our project, we have only **5 carefully selected CBC parameters**, meaning the dimensional density remains compact. However, KNN still performed lowest (73.54%) because it is sensitive to local noise and treats distance equally along all directions, whereas Random Forest gives more weight to the most clinically salient features (like Hemoglobin)."*

---

## Category 4: Model Evaluation & Performance Metrics

### Q12: Why is Accuracy alone dangerous in medical diagnostic systems?
> **Examiner's Angle:** Testing your understanding of clinical AI ethics and metric evaluation.

**Your Answer:**
* *"In clinical medicine, **different errors have vastly different real-world costs**:"*
  * A **False Positive** (diagnosing a healthy person as anemic) leads to unnecessary follow-up blood tests or mild dietary recommendations.
  * A **False Negative** (missing a severely anemic patient or misclassifying thalassemia) can lead to severe organ ischemia, unmanaged cardiovascular complications, or maternal hemorrhage.
* *"If a dataset were imbalanced (e.g., 95% healthy and 5% diseased), a dummy model predicting 'healthy' for everyone would achieve 95% accuracy while failing 100% of sick patients."*
* *"Therefore, in our project we evaluate **Recall (Sensitivity)**, **Precision**, **F1-Score (harmonic mean of Precision and Recall)**, and **Multiclass ROC-AUC** alongside Accuracy."*

---

### Q13: What does the Confusion Matrix show in your test results?
**Your Answer:**
* *"Our held-out test confusion matrices (`results/confusion_matrices.png`) reveal:"*
  1. **Anemic patients** are detected with high sensitivity (minimal confusion with healthy patients because Hemoglobin drops significantly below 11.5 g/dL).
  2. The primary boundary of clinical nuance occurs between **Non-Anemic** and **Compensated Microcytosis**. Because both groups share normal Hemoglobin levels, the model correctly relies on the secondary indices (RBC count and MCV) to disambiguate them.

---

### Q14: Which parameter was the most important feature according to your model?
**Your Answer:**
* *"Based on Gini Feature Importance extracted from the Random Forest model (`results/feature_importance.png`):"*
  1. **Hemoglobin (HGB): 43.48%** — The dominant primary feature deciding anemia presence.
  2. **MCH: 22.11%** — Strong indicator of cellular hypochromia.
  3. **RBC Count: 19.04%** — The decisive feature separating Compensated Microcytosis from Anemia.
  4. **MCV: 12.70%** — Determines microcytic vs normocytic cell sizing.
  5. **MCHC: 2.67%** — Secondary check of cellular concentration.
* *"This statistical feature ranking directly mirrors clinical hematology guidelines."*

---

## Category 5: System Architecture & Presentation Questions

### Q15: Why did you provide all 5 model predictions on your Web UI instead of just one?
**Your Answer:**
* *"In high-stakes clinical decision support, medical practitioners value **algorithmic consensus**."*
* *"When all 5 diverse algorithms (linear, tree-based, ensemble, margin-based, and neighborhood-based) agree on a diagnosis (e.g., all 5 predict 'Anemic'), the clinician can have high confidence in the automated result."*
* *"When the models diverge (e.g., Random Forest predicts 'Compensated Microcytosis' while Logistic Regression predicts 'Non-Anemic'), it signals a borderline clinical profile that warrants manual microscopic peripheral blood smear confirmation."*

---

### Q16: How would this project be deployed in a real-world hospital laboratory?
**Your Answer:**
* *"In a hospital setting, automated hematology analyzers (like Sysmex, Beckman Coulter, or Mindray) generate complete CBC test results in ASTM or HL7 protocol format."*
* *"Our Flask application provides a REST API endpoint (`POST /api/predict`) that accepts JSON payloads directly from Laboratory Information Management Systems (LIMS). The system returns the predicted category, confidence percentage, and clinical advisory alerts in under 20 milliseconds, providing immediate diagnostic assistance to the lab technician before the report is signed off by the pathologist."*
